Translations have moved to https://translate.wordpress.org/projects/wp-plugins/wpcf7-redirect

Your are more than welcome contribute :)
